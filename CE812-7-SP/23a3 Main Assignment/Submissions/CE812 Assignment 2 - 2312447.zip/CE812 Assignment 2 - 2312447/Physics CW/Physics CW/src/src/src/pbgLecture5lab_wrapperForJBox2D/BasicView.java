package src.pbgLecture5lab_wrapperForJBox2D;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;


public class BasicView extends JComponent {
	/* Author: Michael Fairbank
	 * Creation Date: 2016-01-28
	 * Significant changes applied:
	 */
	// Created by Thomas Stoyles - 2312447
	private BufferedImage backgroundImage;
	// background colour
	public static final Color BG_COLOR = Color.BLACK;
	private BasicPhysicsEngineUsingBox2D game;
	// Created by Thomas Stoyles - 2312447
	public BasicView(BasicPhysicsEngineUsingBox2D game) {
		this.game = game;
		try {
			backgroundImage = ImageIO.read(new File("C:\\Users\\Thomas\\Documents\\Uni Masters\\Masters\\CE812 Assignment 2 - 2312447\\Physics CW\\game_bg.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean isDisplayingRules() {
		return displayRules;
	}
	// Created by Thomas Stoyles - 2312447
	private boolean displayRules = true;
	// Created by Thomas Stoyles - 2312447
	private boolean closeButtonAdded = false;
	// Created by Thomas Stoyles - 2312447
	private Rectangle rulesBoxRegion;

	// Created by Thomas Stoyles - 2312447
	private void drawRulesBox(Graphics g) {
		// Draw a box with rules
		int boxWidth = 400;
		int boxHeight = 200;
		int yOffset = 200;
		int x = getWidth() / 2 - boxWidth / 2;
		int y = getHeight() / 2 - boxHeight / 2 - yOffset;
		g.setColor(Color.WHITE);
		g.fillRect(x, y, boxWidth, boxHeight);
		if(!closeButtonAdded) {
			//Draw the button
			JButton closeButton = new JButton("Close");
			closeButton.setBounds(x + 10, y + 150, 80, 30); // Adjust the position and size as needed
			closeButton.addActionListener(e -> closeRulesBox());
			add(closeButton);
			closeButtonAdded = true;
		}

		// Draw the rules inside the box
		g.setColor(Color.BLACK);
		String rules = "Rules:\n1. Aim and shoot the balls using the mouse.\n2. Score 300 or more to win!\n3. Everytime you shoot you get -25 points\n4. If you score -100 you lose!\n5. Yellow is worth 25 points\n6. Red is worth 100 points";
		String[] rulesLines = rules.split("\n");
		int lineHeight = g.getFontMetrics().getHeight();
		int textX = x + 20;
		int textY = y + 40;
		for (String line : rulesLines) {
			g.drawString(line, textX, textY);
			textY += lineHeight;
		}
		rulesBoxRegion = new Rectangle (x, y, boxWidth, boxHeight);
	}

	// Created by Thomas Stoyles - 2312447
	// paintComponent
	@Override
	public void paintComponent(Graphics g0) {
		super.paintComponent(g0);
		BasicPhysicsEngineUsingBox2D game;
		synchronized(this) {
			game = this.game;
		}
		Graphics2D g = (Graphics2D) g0;
		// Paint the background image if it's loaded successfully
		if (backgroundImage != null) {
			g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
		} else {
			// If the background image fails to load, fallback to painting a solid color
			g.setColor(BG_COLOR);
			g.fillRect(0, 0, getWidth(), getHeight());
		}

		if (displayRules){
			drawRulesBox(g);
		}
		int activeIndex = game.getActiveParticleIndex();
		BasicParticle activeParticle = game.particles.get(activeIndex);
		activeParticle.draw(g);
		for (BasicParticle p : game.particles)
			p.draw(g);
		for (BasicPolygon p : game.polygons)
			p.draw(g);
		for (AnchoredBarrier b : game.barriers)
			b.draw(g);

		// Draw the winning message if it is not empty
		if (!game.getWinMessage().isEmpty()) {
			// Draw a box
			int boxWidth = 200;
			int boxHeight = 50;
			int x = getWidth() / 2 - boxWidth / 2;
			int y = getHeight() / 2 - boxHeight / 2;
			g.setColor(Color.WHITE);
			g.fillRect(x, y, boxWidth, boxHeight);

			// Draw the winning message inside the box
			g.setColor(Color.BLACK);
			g.drawString(game.getWinMessage(), x + 10, y + 30);
		}

			// Draw a box to show score
			int boxWidth = 100;
			int boxHeight = 50;
			int x = 500;
			int y = 3;
			g.setColor(Color.WHITE);
			g.fillRect(x, y, boxWidth, boxHeight);

			// Draw the score
			g.setColor(Color.BLACK);
			g.drawString("Score: "+game.score, x + 10, y + 30);

			// Draw area to shoot
			boxWidth = 115;
			boxHeight = 50;
			x = 1;
			y = 450;
			g.setColor(Color.BLUE);
			g.fillRect(x, y, boxWidth, boxHeight);

			// Draw the message inside the box
			g.setColor(Color.BLACK);
			g.drawString("Click here to Shoot", x + 10, y + 40);

	}
	// Created by Thomas Stoyles - 2312447
	// Method to close the rules box and start the game
	public void closeRulesBox() {
		displayRules = false;
		// Remove the close button from the component
		Component[] components = getComponents();
		for (Component component : components) {
			if (component instanceof JButton && ((JButton) component).getText().equals("Close")) {
				remove(component);
				revalidate(); // Revalidate the component hierarchy
				repaint();    // Request a repaint to reflect the changes
				break;
			}
			//System.out.println("Display Rules set to false");
		}
	}
	@Override
	public Dimension getPreferredSize() {
		return BasicPhysicsEngineUsingBox2D.FRAME_SIZE;
	}
	
	public synchronized void updateGame(BasicPhysicsEngineUsingBox2D game) {
		this.game=game;
	}
}