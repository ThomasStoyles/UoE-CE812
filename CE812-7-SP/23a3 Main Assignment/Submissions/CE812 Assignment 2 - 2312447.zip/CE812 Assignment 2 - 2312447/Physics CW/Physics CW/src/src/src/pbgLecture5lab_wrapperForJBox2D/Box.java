package src.pbgLecture5lab_wrapperForJBox2D;

import javafx.scene.shape.Rectangle;

// Created by Thomas Stoyles - 2312447
public class Box extends Rectangle {
    private double initialX;
    private double initialY;

    public Box(double x, double y, double width, double height) {
        super(x, y, width, height);
        this.initialX = x;
        this.initialY = y;
    }

    public void resetPosition() {
        this.setX(initialX);
        this.setY(initialY);
    }
}

