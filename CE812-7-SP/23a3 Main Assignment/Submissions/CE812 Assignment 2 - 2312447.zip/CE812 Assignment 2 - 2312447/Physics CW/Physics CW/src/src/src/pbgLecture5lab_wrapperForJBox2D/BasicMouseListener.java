package src.pbgLecture5lab_wrapperForJBox2D;

import java.awt.event.MouseEvent;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.MouseInputAdapter;

import org.jbox2d.callbacks.QueryCallback;
import org.jbox2d.collision.AABB;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.Fixture;
import org.jbox2d.dynamics.joints.MouseJoint;
import org.jbox2d.dynamics.joints.MouseJointDef;

public class BasicMouseListener extends MouseInputAdapter {
	/* Author: Michael Fairbank
	 * Creation Date: 2016-01-28
	 * Significant changes applied: 2016-02-10 added mouseJoint code to allow dragging of bodies
	 */
	private static int mouseX, mouseY;
	public static boolean mouseButtonPressed;
	public static Vec2 startMousePos = new Vec2(0,0);
	public static Vec2 endMousePos;
	// Created by Thomas Stoyles - 2312447
	public static Vec2 launchVector = new Vec2(0,0);


	public void mouseMoved(MouseEvent e) {
		mouseX = e.getX();
		mouseY = e.getY();
		if (mouseButtonPressed) {
			mouseButtonPressed = false;
			mouseReleased(e);
		}
	}


	public void mouseDragged(MouseEvent e) {
		mouseX=e.getX();
		mouseY=e.getY();
		mouseButtonPressed=true;
		if (startMousePos.x == 0){
			startMousePos = new Vec2(BasicPhysicsEngineUsingBox2D.convertScreenXtoWorldX(mouseX), BasicPhysicsEngineUsingBox2D.convertScreenYtoWorldY(mouseY));
			//System.out.println(startMousePos.x + "   " + startMousePos.y);
		}
		//System.out.println("Drag event: "+mouseX+","+mouseY);
	}

	// Created by Thomas Stoyles - 2312447
	public void mouseReleased(MouseEvent e) {
		endMousePos = new Vec2(BasicPhysicsEngineUsingBox2D.convertScreenXtoWorldX(mouseX), BasicPhysicsEngineUsingBox2D.convertScreenYtoWorldY(mouseY));
		if (startMousePos != null && endMousePos != null) {
			// Calculate launch vector and apply it to the ball
			launchVector = endMousePos.sub(startMousePos);
			float scaleFactor = 80.0f; // Adjust this scale factor as needed
			launchVector = launchVector.mul(scaleFactor);
		}
		startMousePos = new Vec2(0,0);
	}

}


