package src.pbgLecture5lab_wrapperForJBox2D;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import java.util.ArrayList;
import java.util.List;
import src.pbgLecture5lab_wrapperForJBox2D.BallRespawner;

import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.World;

public class BasicPhysicsEngineUsingBox2D {
	// frame dimensions
	public static final int SCREEN_HEIGHT = 680;
	public static final int SCREEN_WIDTH = 640;
	public static final Dimension FRAME_SIZE = new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT);
	public static final float WORLD_WIDTH = 10; // meters
	public static final float WORLD_HEIGHT = SCREEN_HEIGHT * (WORLD_WIDTH / SCREEN_WIDTH); // meters - keeps world dimensions in same aspect ratio as screen dimensions, so that circles get transformed into circles as opposed to ovals
	public static final float GRAVITY = 9.8f;
	public static final boolean ALLOW_MOUSE_POINTER_TO_DRAG_BODIES_ON_SCREEN = true; // There's a load of code in basic mouse listener to process this, if you set it to true

	public static World world; // Box2D container for all bodies and barriers

	// sleep time between two drawn frames in milliseconds
	public static final int DELAY = 20;
	public static final int NUM_EULER_UPDATES_PER_SCREEN_REFRESH = 20;
	// estimate for time between two frames in seconds
	public static final float DELTA_T = DELAY / 1000.0f;

	public static int convertWorldXtoScreenX(float worldX) {
		return (int) (worldX / WORLD_WIDTH * SCREEN_WIDTH);
	}

	public static int convertWorldYtoScreenY(float worldY) {
		// minus sign in here is because screen coordinates are upside down.
		return (int) (SCREEN_HEIGHT - (worldY / WORLD_HEIGHT * SCREEN_HEIGHT));
	}

	public static float convertWorldLengthToScreenLength(float worldLength) {
		return (worldLength / WORLD_WIDTH * SCREEN_WIDTH);
	}

	public static float convertScreenXtoWorldX(int screenX) {
		return screenX * WORLD_WIDTH / SCREEN_WIDTH;
	}

	public static float convertScreenYtoWorldY(int screenY) {
		return (SCREEN_HEIGHT - screenY) * WORLD_HEIGHT / SCREEN_HEIGHT;
	}


	public List<BasicParticle> particles;
	private int activeParticleIndex = 0;
	public List<BasicPolygon> polygons;
	public List<AnchoredBarrier> barriers;
	// Created by Thomas Stoyles - 2312447
	public Vec2 launch = new Vec2(100.0f, 0.0f);
	public int total, current;
	// Created by Thomas Stoyles - 2312447
	public int ball = 0;
	// Created by Thomas Stoyles - 2312447
	private String winMessage = "";
	// Created by Thomas Stoyles - 2312447
	public int getScore(){
		return score;
	}
	// Created by Thomas Stoyles - 2312447
	public int score = 25;
	public int getActiveParticleIndex() {
		return activeParticleIndex;
	}

	public static enum LayoutMode {
		CONVEX_ARENA, CONCAVE_ARENA, CONVEX_ARENA_WITH_CURVE, PINBALL_ARENA, RECTANGLE, SNOOKER_TABLE, DEMOLITION
	};


	public BasicPhysicsEngineUsingBox2D() {
		world = new World(new Vec2(0, -GRAVITY));// create Box2D container for everything
		world.setContinuousPhysics(true);
		particles = new ArrayList<BasicParticle>();
		polygons = new ArrayList<BasicPolygon>();
		barriers = new ArrayList<AnchoredBarrier>();
		Vec2 ballStart = new Vec2(WORLD_WIDTH / 7, WORLD_HEIGHT / 2.5f);
		LayoutMode layout = LayoutMode.CONVEX_ARENA;

		float linearDragForce = 0.0035f;

		// Created by Thomas Stoyles - 2312447
		//Balls
		particles.add(new BasicParticle(0.33f, 3f, 0, 0, 0.25f, Color.GREEN, 1f, 0.01f));
		particles.add(new BasicParticle(0.33f, 0.5f, 0, 0, 0.15f, Color.RED, 0.65f, 0.01f));
		particles.add(new BasicParticle(0.5f, 0.75f, 0, 0, 0.35f, Color.BLUE, 1.45f, 0.01f));
		// Objective bottom left
		polygons.add(new BasicPolygon(4.2f, 1.8f, 0f, 0f, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		polygons.add(new BasicPolygon(4.45f, 1.8f, 0f, 0f, 0.25f, Color.RED, 3, linearDragForce, 6));
		polygons.add(new BasicPolygon(4.65f, 1.8f, 0f, 0f, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		polygons.add(new BasicPolygon(4.65f, 2.4f, 0f, 0f, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		polygons.add(new BasicPolygon(4.45f, 2.4f, 0f, 0f, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		polygons.add(new BasicPolygon(4.2f, 2.4f, 0f, 0f, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		// Objective Far right
		polygons.add(new BasicPolygon(9.25f, 3.75f, 0f, 0F, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		polygons.add(new BasicPolygon(9.75f, 3.75f, 0f, 0f, 0.25f, Color.RED, 3, linearDragForce, 8));
		polygons.add(new BasicPolygon(9.25f, 4.05f, 0f, 0F, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		polygons.add(new BasicPolygon(9.25f, 4.35f, 0f, 0F, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		// Objective Middle
		polygons.add(new BasicPolygon(5.75f, 4.25f, 0f, 0f, 0.25f, Color.YELLOW, 3, linearDragForce, 4));
		polygons.add(new BasicPolygon(6.25f, 4.25f, 0f, 0f, 0.25f, Color.RED, 3, linearDragForce, 8));
		polygons.add(new BasicPolygon(6.65f, 4.25f, 0f, 0f, 0.25f, Color.YELLOW, 3, linearDragForce, 4));

		barriers = new ArrayList<AnchoredBarrier>();

        switch (layout) {
			case RECTANGLE: {
				// rectangle walls:
				// anticlockwise listing
				// These would be better created as a JBox2D "chain" type object for efficiency and potentially better collision detection at joints.
				barriers.add(new AnchoredBarrier_StraightLine(0, 0, WORLD_WIDTH, 0, Color.WHITE));
				barriers.add(new AnchoredBarrier_StraightLine(WORLD_WIDTH, 0, WORLD_WIDTH, WORLD_HEIGHT, Color.WHITE));
				barriers.add(new AnchoredBarrier_StraightLine(WORLD_WIDTH, WORLD_HEIGHT, 0, WORLD_HEIGHT, Color.WHITE));
				barriers.add(new AnchoredBarrier_StraightLine(0, WORLD_HEIGHT, 0, 0, Color.WHITE));
				break;
			}
			case CONVEX_ARENA: {
				// Created by Thomas Stoyles - 2312447
				// Outline
				barriers.add(new AnchoredBarrier_StraightLine(0, 0, WORLD_WIDTH, 0, Color.WHITE)); // bottom
				barriers.add(new AnchoredBarrier_StraightLine(0, WORLD_WIDTH, WORLD_WIDTH, WORLD_WIDTH, Color.WHITE)); // top
				barriers.add(new AnchoredBarrier_StraightLine(0, 0, 0, WORLD_WIDTH, Color.WHITE)); // left
				barriers.add(new AnchoredBarrier_StraightLine(WORLD_WIDTH, 0, WORLD_WIDTH, WORLD_WIDTH, Color.WHITE)); // right
				//Ball Holder
				barriers.add(new AnchoredBarrier_StraightLine(0.85f, 0, 0.85f, WORLD_HEIGHT-8.5F, Color.WHITE)); // right ball holder wall
				barriers.add(new AnchoredBarrier_StraightLine(0, WORLD_HEIGHT-8.5f, 0.85f, WORLD_HEIGHT-8.5f, Color.WHITE)); // top incasing
				barriers.add(new AnchoredBarrier_StraightLine(0, WORLD_HEIGHT-2, WORLD_WIDTH, WORLD_HEIGHT-2, Color.WHITE)); // top ball holder
				//Platforms
				barriers.add(new AnchoredBarrier_StraightLine(3.5f, 1.5f, 5f, 1.5f, Color.BLUE));
				barriers.add(new AnchoredBarrier_StraightLine(5.5f, 4f, 7f, 4f, Color.GREEN));
				barriers.add(new AnchoredBarrier_StraightLine(9f, 3.5f, WORLD_WIDTH, 3.5f, Color.PINK));
				//Platform stopper
				barriers.add(new AnchoredBarrier_StraightLine(5.5f, 4.5f, 5.5f, 6f, Color.RED));
				barriers.add(new AnchoredBarrier_StraightLine(8f, 6.5f, 9f, 6.5f, Color.RED));
				break;
			}
		}

	}
	// Created by Thomas Stoyles - 2312447
	public void update() {
		int VELOCITY_ITERATIONS = NUM_EULER_UPDATES_PER_SCREEN_REFRESH;
		int POSITION_ITERATIONS = NUM_EULER_UPDATES_PER_SCREEN_REFRESH;
		total = polygons.size();

		if (score >= 300){
			winMessage = "Well Done, You win";
		}
		if (score <= -100) {
			winMessage = "You lose";
		}

		for (BasicParticle p:particles) {
			p.notificationOfNewTimestep();
		}

		for (BasicPolygon p : polygons) {
			if (p.body.getPosition().y < 0.4f && p.body.getAngularVelocity() == 0.0f) {
				// Move the polygon to the top of the screen and add a force
				p.body.setTransform(new Vec2(1.0f, 9.0f), 0.0f);
				p.body.applyForceToCenter(new Vec2(5, 0));
				if(p.col == Color.YELLOW){
					score += 25;
					System.out.println("Score: " + score);
				}else if (p.col == Color.RED){
					score += 100;
					System.out.println("Score : " + score);
				}
				current++;
			}
			p.notificationOfNewTimestep();
		}

		if(launch!= BasicMouseListener.launchVector){
			if(ball == 3){
				ball = 0;
			}
			if(ball != 0 ){
				particles.get(ball-1).body.setTransform(new Vec2(0.35f, 2f), 0.0f);
				particles.get(ball-1).body.applyForceToCenter(new Vec2(0, 0));
				particles.get(ball).start();
				particles.get(ball).body.applyForceToCenter(BasicMouseListener.launchVector);
				launch = BasicMouseListener.launchVector;
			}else{
				particles.get(2).body.setTransform(new Vec2(0.35f, 2f), 0.0f);
				particles.get(2).body.applyForceToCenter(new Vec2(0f, 0f));
				particles.get(ball).start();
				particles.get(ball).body.applyForceToCenter(BasicMouseListener.launchVector);
				launch = BasicMouseListener.launchVector;
			}
			score -= 25;
			ball++;
		}

		world.step(DELTA_T, VELOCITY_ITERATIONS, POSITION_ITERATIONS);
	}

	public static void main(String[] args) throws Exception {
		final BasicPhysicsEngineUsingBox2D game = new BasicPhysicsEngineUsingBox2D();
		final BasicView view = new BasicView(game);
		pbgLecture5lab_wrapperForJBox2D.JEasyFrame frame = new pbgLecture5lab_wrapperForJBox2D.JEasyFrame(view, "Thomas Stoyles - 2312447");
		view.addMouseMotionListener(new BasicMouseListener());
		game.startThread(view);
	}

	// Created by Thomas Stoyles - 2312447
	private void startThread(final BasicView view) throws InterruptedException {
		final BasicPhysicsEngineUsingBox2D game = this;
		while (view.isDisplayingRules()){
			view.repaint();
			Toolkit.getDefaultToolkit().sync();
			try{
				Thread.sleep(DELAY);
			}catch (InterruptedException e){

			}
		}
		while (true) {
			game.update();
			view.repaint();
			Toolkit.getDefaultToolkit().sync();
			try {
				Thread.sleep(DELAY);
			} catch (InterruptedException e) {
			}
		}
	}
	// Created by Thomas Stoyles - 2312447
	public String getWinMessage() {
		return winMessage;
	}
}
