package src.pbgLecture5lab_wrapperForJBox2D;

import org.jbox2d.common.Vec2;
// Created by Thomas Stoyles - 2312447
public class BallRespawner {
    public src.pbgLecture5lab_wrapperForJBox2D.BasicParticle ball;
    public Vec2 startingPosition;

    public BallRespawner(src.pbgLecture5lab_wrapperForJBox2D.BasicParticle ball, Vec2 startingPosition) {
        this.ball = ball;
        this.startingPosition = startingPosition;
    }

    public void respawnBall() {
        ball.body.setTransform(startingPosition, 0); // Reset ball's position
        ball.body.setLinearVelocity(new Vec2(0, 0)); // Reset ball's velocity
    }
}
